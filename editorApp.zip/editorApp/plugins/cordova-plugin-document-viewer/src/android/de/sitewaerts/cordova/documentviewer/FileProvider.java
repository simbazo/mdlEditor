package de.sitewaerts.cordova.documentviewer;

public class FileProvider extends android.support.v4.content.FileProvider {
}
